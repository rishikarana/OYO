#! python3
# bullet_adder.py - this is the program name. The first kine is the shebang line

#pre requisites of this program are to copy the contents to be bulleted into the clipboard
#importing library
import pyperclip

#paste the text to variable text
text=pyperclip.paste()

#split the text linewise
lines=text.splitlines()

#add bullet to everyline
for i in range(len(lines)):
    lines[i]='*\t'+str(lines[i])

#join back each line
text='\n'.join(lines)

#copy the text to the clipboard
pyperclip.copy(text)
