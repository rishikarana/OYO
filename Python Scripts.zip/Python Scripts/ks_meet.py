# -*- coding: utf-8 -*-
"""
Created on Tue Dec  4 12:18:15 2018

@author: rxr318
"""

import pandas as pd
state=pd.read_excel("Z://Rishika//sttes.xlsx")
sa_ly=pd.read_sas("Z://Rishika//sa_data.sas7bdat",format="sas7bdat",encoding="ISO-8859-1")

#left joining with the state table
sa_ly_final=pd.merge(sa_ly,state,how='left',left_on='ShopCode',right_on='Code')

#extracting month from the dates
sa_ly_final['month'] = pd.DatetimeIndex(sa_ly_final['tran_date']).month


ams_trn=sa_ly_final.groupby(['State','month'],as_index = False).agg({'PrivilegeCustomerCode':['nunique'],'Tran_Id':['nunique'],'itemquantity':['sum'],'spend':['sum']})
ams_trn_overll_ly=sa_ly_final.groupby(['State'],as_index=False).agg({'PrivilegeCustomerCode':['nunique'],'Tran_Id':['nunique'],'itemquantity':['sum'],'spend':['sum']})
demo=pd.read_sas("Z://Landmark Useful//Member Demographics//member_demographics_july18.sas7bdat",format="sas7bdat",encoding="ISO-8859-1")
ams_trn.pivot('State');