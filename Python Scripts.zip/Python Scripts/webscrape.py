# -*- coding: utf-8 -*-
"""
Created on Fri Oct  5 10:39:31 2018

@author: rxr318
"""
import pandas as pd
from selenium import webdriver 
from selenium.webdriver.common.by import By 
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC 
from selenium.common.exceptions import TimeoutException

option = webdriver.ChromeOptions()
option.add_argument(" — incognito")

browser = webdriver.Chrome()
browser.implicitly_wait(5)
browser.get("https://www.accuweather.com/en/ae/dubai/323091/november-weather/323091?monyr=11/1/2018&view=table")
timeout=20

try:
    WebDriverWait(browser, timeout).until(EC.visibility_of_element_located((By.XPATH, "//*[@id='header-logo']")))
except TimeoutException:
    print("Timed out waiting for page to load")
    browser.quit()
  
final_list=list()
#making list of cities in specific territory
#citylist=['Barka, om','Ibri, om','Muscat, om','Nizwa, om','Ruwi, om','Salalah, om','Sohar, om']
#citylist=['Salalah, om','Sohar, om']
#same for other territories
#citylist=['Abu Dhabi, ae','Ajman, ae','Al Ain, ae','Dubai ae','Fujairah ae','Ras Al Khaimah ae','Sharjah, ae']
#citylist=['Fahahil, kw','al Farwaniyah, kw','Hawalli, kw','al Jahra, kw','Abraq Khaytan, kw']
citylist1=pd.read_excel("sa_cities1.xlsx")
citylist=citylist1['Unnamed: 2']
#looping for everycity in the territory
for i in range(len(citylist)):
    #search box to search the city
    search_box = browser.find_element_by_xpath("//input[@id='s' and @name='s']")
    #click on search box
    search_box.click()
    search_box.send_keys(citylist[i])
    search_button=browser.find_element_by_xpath("//button[@class='bt bt-go']")
    search_button.click()
    month_link=browser.find_element_by_xpath("//li[@data-label='fcst_nav_forecast_month']")
    month_link.click()
    #click on view as list
    WebDriverWait(browser, timeout).until(EC.visibility_of_element_located((By.XPATH, "//*[@id='panel-main']/div[2]/div/div/div[1]/div/div[1]/ul/li[1]/a")))
    view_as_table=browser.find_element_by_xpath("//*[@id='panel-main']/div[2]/div/div/div[1]/div/div[1]/ul/li[1]/a")
    view_as_table.click()
    table_element = browser.find_elements_by_xpath("//*[@id='panel-main']/div[2]/div/div/table")
    tablecont1 = [x.text for x in table_element]
    tablecont1=str(tablecont1)
    lines1=tablecont1.split(r'\n')
    for j in range(len(lines1)):
        lines1[j]+=' '+citylist[i]
    next_month=browser.find_element_by_xpath("//a[@class='rt next-month float-right']")
    next_month.click()
    view_as_table=browser.find_element_by_xpath("//a[text()='As List' and @class='btr-active btr btri btri-view-list']")
    view_as_table.click()
    table_element = browser.find_elements_by_xpath("//*[@id='panel-main']/div[2]/div/div/table")
    tablecont2 = [x.text for x in table_element]
    tablecont2=str(tablecont2)
    lines2=tablecont2.split(r'\n')
    for j in range(len(lines2)):
        lines2[j]+=' '+citylist[i]
    next_month=browser.find_element_by_xpath("//a[@class='rt next-month float-right']")
    next_month.click()
    view_as_table=browser.find_element_by_xpath("//a[text()='As List' and @class='btr-active btr btri btri-view-list']")
    view_as_table.click()
    table_element = browser.find_elements_by_xpath("//*[@id='panel-main']/div[2]/div/div/table")
    tablecont3 = [x.text for x in table_element]
    tablecont3=str(tablecont3)
    lines3=tablecont3.split(r'\n')
    for j in range(len(lines3)):
        lines3[j]+=' '+citylist[i]
    
    lines1+=lines2+lines3
    final_list+=lines1
df_data=pd.DataFrame(data=final_list)
df_data.to_excel('sa_new1.xlsx', sheet_name='sa', index=False)