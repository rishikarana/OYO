
# coding: utf-8

# In[12]:


#! python3
# Email_content.py - 
content = {'job': 'Hi, I am sending this email to you with reference to your post on facebook. I am an enthusiastic data analyst.'}

import sys, pyperclip
if len(sys.argv) < 2:
    print('Usage: py Email_content.py [account] - copy email content')
    sys.exit()

account = sys.argv[1]   # first command line arg is the account name

if account in content:
    pyperclip.copy(content[account])
    print('Email content ' + account + ' copied to clipboard.')
else:
    print('There is no account named ' + account)

