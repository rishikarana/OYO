# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 12:51:45 2018

@author: rxr318
"""
import pandas as pd
ae=pd.read_sas("//efxsasserver//Retail_team//max1//transactions_data//tran_level//tran_ae.sas7bdat",format = 'sas7bdat', encoding="ISO-8859-1")

yasmall1=pd.DataFrame(ae.loc[(ae['ShopCode'].isin(['60233'])) &( ae['tran_date']>='2017-10-18') & (ae['tran_date']<='2018-10-17')][['PrivilegeCustomerCode']].PrivilegeCustomerCode.unique())
yasmall1.rename(columns={0:'PrivilegeCustomerCode'},inplace=True)

chunksize = 10 ** 6
filename="//EFXSASSERVER//Retailclient_data//Territory_data//Tran Level//lmg_tran_jan15_latest_ae.sas7bdat"
c=pd.DataFrame()
for chunk in pd.read_sas(filename, chunksize=chunksize ,format = 'sas7bdat', encoding="ISO-8859-1"):
    c.append(chunk)
lmg_ae=pd.read_sas("//EFXSASSERVER//Retailclient_data//Territory_data//Tran Level//lmg_tran_jan15_latest_ae.sas7bdat",format = 'sas7bdat', encoding="ISO-8859-1")

yassmall2=pd.DataFrame(lmg_ae.loc[(lmg_ae['Shopcode'].isin(['21183',
'22038',
'25010',
'20233',
'20194',
'20169',
'20170',
'20172',
'20173',
'20176',
'20171',
'20286',
'34015',
'40051',
'JJ20',
'CR13',
'JJ11',
'PF11',
'PF13',
'11094',
'80064',
'168158',
'LFL6',
'17095',
'60233',
'10307',
'10915',
'LCF2']))& (lmg_ae['tran_date']>='2017-10-18') & (lmg_ae['tran_date']<='2018-10-17')][['PrivilegeCustomerCode']].PrivilegeCustomerCode.unique())
yasmall2=~yasmall2.isin(yasmall1['PrivilegeCustomerCode'])
yasmall2.rename(columns={0:'PrivilegeCustomerCode'},inplace=True)

yasmall1['tg']=1
yasmall2['tg']=2

pd.concat([yasmall1, yasmall2])



