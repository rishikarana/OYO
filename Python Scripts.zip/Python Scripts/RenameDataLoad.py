# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 11:10:06 2019

@author: rxr318
"""

#! python3

import os
path="//EFXSASSERVER//Retail_team//SASuser//Data loading//Input Files//Raw Files//NonIEB"
i = 1
for filename in os.listdir(path):
    os.rename(path+'/'+filename, path+'/Netpositive'+str(i)+'.csv')
    i = i +1